package dev.rodolfo.exception;

public class ValorInvalidoException extends Exception {
    public ValorInvalidoException(String message) {
        super(message);
    }
}
